package tests;

import com.dao.BookDao;
import com.dao.impl.BookImpl;
import com.models.Book;



public class BookTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
BookDao bookDao = new BookImpl();
		
	Book book = new Book(1,"technical","mcgrawhill","digitalcommu","rutika",45,50);
		
		boolean isAdded = bookDao.addBooks(book);
		bookDao.closeConnection();

	}

}
