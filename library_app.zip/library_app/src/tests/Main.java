package tests;

import com.dao.AdminDao;
import com.dao.impl.AdminDaoImpl;
import com.models.User;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AdminDao userDao = new AdminDaoImpl();
		
		User user = new User("abcd","defe","rutika1","12345","8383060106","s@gmail.com");
		
		boolean isAdded = userDao.addUser(user);
		System.out.println("User Added :: "+isAdded);
	
		
		userDao.closeConnection();
	}


	}


