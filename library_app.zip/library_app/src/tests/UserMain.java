package tests;

import com.dao.UserDao;
import com.dao.impl.UserDaoImpl;
import com.models.Userinfo;

public class UserMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserDao userDao1 = new UserDaoImpl();
		
		Userinfo user = new Userinfo("abc","def","rutika","12345","rtu","8383060106","s@gmail.com");
		
		boolean isAdded = userDao1.addUser(user);
		System.out.println("User Added :: "+isAdded);
		/*userDao.addUser(new User("Amol","Joshi","amol@123","amol123","8899999999","amol@abc.in"));*/
		
		/*User user = userDao.getUser("ameya@123");
		System.out.println(user);
		System.out.println("----------------------------------");*/
		//Iterator<User> itr = userDao.getAllUsers().iterator();
		/*while(itr.hasNext())
		{
			System.out.println(itr.next());
		}*/
		
		userDao1.closeConnection();
	}


	}


