package com.validations1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.AdminDao;
import com.dao.impl.AdminDaoImpl;
import com.models.User;


public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdminDao userDao;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("+++++++ INIT() ++++++++++");
		userDao = new AdminDaoImpl();
	}
	
       
    
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("Text/html");
		PrintWriter out = response.getWriter();
		/*int userId=Integer.parseInt(request.getParameter("userId"));*/
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		 String contact=request.getParameter("contact");
	   String email=request.getParameter("email");
	 
		User user = new User(fname,lname,username,password,contact,email);
		boolean isAdded = userDao.addUser(user);
		if(isAdded==true)
		{
			
			out.println("<img src='image2.jpg' alt='image' />");
			out.println("background-repeat: no-repeat");
			out.println("background-size:cover");
			/*out.println("Welcome <I>User<B>"+user.getUsername()+"</B></I>");*/
			out.println("<p>Configuration !!! You have registered successfully</p>");
			out.println("<BR><A href=Login.jsp>Login Now!</A>");
			out.println("</body>");
		}else{
			out.println("<body bgcolor='cyan'>");
			out.println("<center><h3>Welcome To Om Library Management System</h3></center>");
			out.println("<p>Error DUring Registration !!!</p>");
			out.println("<BR><A href=Registration.jsp>Re-Register!</A>");
			out.println("</body>");
		}
	
	
	}
		
		
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	public void destroy() {
		userDao.closeConnection();
		}

}
