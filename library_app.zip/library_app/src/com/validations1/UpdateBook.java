package com.validations1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.BookDao;
import com.dao.impl.BookImpl;
import com.models.Book;


public class UpdateBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BookDao  bookDao;
	private ServletContext context;
	private String welcomeMsg;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("++++++++++++++++ init() invoked ++++++++");
		bookDao = new BookImpl();
		context=config.getServletContext();
		welcomeMsg=context.getInitParameter("welcomeMsg");
	}
       
  
    public UpdateBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		int bookid=Integer.parseInt(request.getParameter("bookid"));
		String category=request.getParameter("category");
		String publication=request.getParameter("publication");
		String bookname=request.getParameter("bookname");
		 String author=request.getParameter("author");
	   int copies=Integer.parseInt(request.getParameter("copies"));
	   int price=Integer.parseInt(request.getParameter("price"));
		
		Book book = new Book();
		book.setBookid(bookid);
		
		book.setCategory(category);
		book.setPublication(publication);
		book.setBookname(bookname);
		book.setAuthor(author);
		book.setCopies(copies);
		book.setPrice(price);
		
		
		boolean isAdded= bookDao.updateBooks(book);
		
		if(isAdded==true){
			out.println("<img src='99.jpg' alt='image' />");
			out.println("<center><h3>OM Book Library</h3></center>");
			
			out.println("<p>Congratulations !!! You have Updated product Successfuly...</p>");
			out.println("<BR><A href=bookstore.jsp>Back !</A>");
			out.println("</body>");
		}else{
			out.println("<img src='99.jpg' alt='image' />");
			
			out.println("<p>Error  During Updation!!!</p>");
			
			out.println("</body>");
		}
		
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	public void destroy() {
		bookDao.closeConnection();
			}

}
