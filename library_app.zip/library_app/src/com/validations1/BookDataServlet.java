package com.validations1;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jdbcconnection.JdbcConnection;


public class BookDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public BookDataServlet() {
        super();
       
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("Text/html");
		
		
		String category=request.getParameter("category");
		String publication=request.getParameter("publication");
		String bookname=request.getParameter("bookname");
		 String author=request.getParameter("author");
	   int copies=Integer.parseInt(request.getParameter("copies"));
	   int price=Integer.parseInt(request.getParameter("price"));
		
		Connection con=JdbcConnection.getConnection();
		String query="insert into books values(?,?,?,?,?,?,?)";
		Statement st=null;
		int bookid=0;
		try {
			st = con.createStatement();
			ResultSet rs=st.executeQuery("select max(bookid) from books");
			rs.next();
			bookid=(rs.getInt(1)+1);
			PreparedStatement pst;
			pst = con.prepareStatement(query);
			pst.setInt(1,bookid);
			pst.setString(2,category);
			pst.setString(3,publication);
			pst.setString(4,bookname);
			pst.setString(5,author);
			pst.setInt(6,copies);
			pst.setInt(7,price);
			int k=pst.executeUpdate();           
			con.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		response.sendRedirect("BookInventory.jsp");
		
	}

}
