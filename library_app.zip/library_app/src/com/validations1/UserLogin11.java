package com.validations1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





import com.dao.AdminDao;
import com.dao.UserDao;
import com.dao.impl.AdminDaoImpl;
import com.dao.impl.UserDaoImpl;
import com.models.Userinfo;


public class UserLogin11 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDao userDao1;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("+++++++ INIT() ++++++++++");
		userDao1 = new UserDaoImpl();
	}
       
    
//    public UserLogin11() {
//        super();
//        // TODO Auto-generated constructor stub
//    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		String username= request.getParameter("username");
		String password= request.getParameter("password");
		Userinfo user = new Userinfo();
		user.setUsername(username);
		user.setPassword(password);
		System.out.println(user.getUsername()+" "+user.getPassword());
		boolean isValid = userDao1.validateUser(user);
		if(isValid==true)
		{
			out.println("<img src='hh.jpg' alt='image' />");
		    out.println("User is Valid");
			out.println("</body>");
			out.println("<BR><A href=studentsection.jsp>Click Here to Continue!</A>");
		}else{
			out.println("<img src='hh.jpg' alt='image' />");
			out.println("<p>Either user or password invalid</p>");
			out.println("<BR><A href=UserLogin.jsp>Re-Login!</A>");
			out.println("</body>");
		}
		
	
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	public void destroy() {
		userDao1.closeConnection();
	}


}
