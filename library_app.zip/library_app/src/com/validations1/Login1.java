package com.validations1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.models.User;
import com.dao.AdminDao;
import com.dao.impl.AdminDaoImpl;


public class Login1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdminDao userDao;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("+++++++ INIT() ++++++++++");
		userDao = new AdminDaoImpl();
	}
       
    
    public Login1() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		String username= request.getParameter("username");
		String password= request.getParameter("password");
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		System.out.println(username+" "+password);
		boolean isValid = userDao.validateUser(user);
		if(isValid==true)
		{
			out.println("<body bgcolor='cyan'>");
		    out.println("User is Valid");
			out.println("</body>");
			out.println("<BR><A href=bookstore.jsp>press here to continue!!!!</A>");
		}else{
			out.println("<body bgcolor='cyan'>");
			out.println("<p>Either user or password invalid</p>");
			out.println("<BR><A href=Login.jsp>Re-Login!</A>");
			out.println("</body>");
		}
		
	
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	public void destroy() {
		userDao.closeConnection();
	}


}
