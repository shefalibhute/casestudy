package com.validations1;

import java.io.IOException;



import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.BookDao;
import com.dao.impl.BookImpl;
import com.models.Book;
import com.models.User;



public class Bookdata extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BookDao bookDao;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("+++++++ INIT() ++++++++++");
		bookDao = new BookImpl();
	}
       
    
    public Bookdata() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("Text/html");
		PrintWriter out = response.getWriter();
		int bookid=Integer.parseInt(request.getParameter("bookid"));
		String category=request.getParameter("category");
		String publication=request.getParameter("publication");
		String bookname=request.getParameter("bookname");
		 String author=request.getParameter("author");
	   int copies=Integer.parseInt(request.getParameter("copies"));
	   int price=Integer.parseInt(request.getParameter("price"));
	 
		Book book = new Book(bookid,category,publication,bookname,author,copies,price);
		boolean isAdded = bookDao.addBooks(book);
		if(isAdded==true)
{
			
			out.println("<img src='19.jpg' alt='image' />");
			out.println("background-repeat: no-repeat");
			out.println("background-size:cover");
			
			out.println("<BR><A href=Books.jsp>insert more books!</A>");
			out.println("<p>You have successfully added book</p>");
			out.println("</body>");
		}else{
			out.println("<img src='19.jpg' alt='image' />");
			out.println("<center><h3>Welcome To Om Library Management System</h3></center>");
			out.println("<center><p>Error DUring adding !!!</p></center>");
			out.println("<center><BR><A href=bookstore.jsp>Re-add!</A></center>");
			out.println("</body>");
		}
	
	
	}
		
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		}
		public void destroy() {
		bookDao.closeConnection();
			}
}



