package com.validations1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.IssueDao;
import com.dao.impl.IssueDaoImpl;
import com.models.Issue;

public class IssueServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// private IssueDao issueDao;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("+++++++ INIT() ++++++++++");
		// issueDao = new IssueDaoImpl();
	}

	public IssueServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// TODO Auto-generated method stub
		response.setContentType("Text/html");
		PrintWriter out = response.getWriter();

		String username = request.getParameter("username");
		String bookname = request.getParameter("bookname");

		/*
		 * int bid=Integer.parseInt(request.getParameter("bookissueid"));
		 * 
		 * int userid=Integer.parseInt(request.getParameter("userid")); int
		 * bookid=Integer.parseInt(request.getParameter("bookid")); String
		 * issuedate=request.getParameter("issuedate"); String
		 * returndate=request.getParameter("returndate"); String
		 * status=request.getParameter("status");
		 */

		/*
		 * Issue issue = new
		 * Issue(bid,bookname,userid,bookid,issuedate,returndate,status);
		 */
		Issue issue = new Issue();
		issue.setUsername(username);
		issue.setBookname(bookname);

		IssueDao iss = new IssueDaoImpl();
		boolean isAdded = iss.issueBooks(issue);
		if (isAdded) {

			out.println("<body background='20.jpg'>");
			out.println("<p>Congratulations !!! You have issued book Successfuly...</p>");
			out.println("<BR><A href=bookissue.jsp>insert more books!</A>");

			out.println("</body>");
		} else {
			out.println("<body background='20.jpg'>");
			out.println("<center><h3>Welcome To Om Library Management System</h3></center>");
			out.println("<p>Error During adding !!!</p>");
			out.println("<BR><A href=bookissue.jsp>back</A>");
			out.println("</body>");
		}

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	/*
	 * public void destroy() { issueDao.closeConnection(); }
	 */
}
