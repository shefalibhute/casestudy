package com.validations1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.UserDao;
import com.dao.impl.UserDaoImpl;
import com.models.Userinfo;



public class UserRegister11 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDao userDao;
	
	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("+++++++ INIT() ++++++++++");
		userDao = new UserDaoImpl();
	}
	
       
    
//    public UserRegister11() {
//        super();
//        
//    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("Text/html");
		PrintWriter out = response.getWriter();
		
		/*int userId=Integer.parseInt(request.getParameter("userId"));*/
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
	    String contact=request.getParameter("contact");
	   String email=request.getParameter("email");
		String membtype=request.getParameter("radiocm");
	   
		//System.out.println(fname);
		
		Userinfo user = new Userinfo();
		user.setFname(fname);
		user.setLname(lname);
		user.setUsername(username);
		user.setPassword(password);
		user.setContact(contact);
		user.setEmail(email);
		user.setMembtype(membtype);
		
		boolean isAdded = userDao.addUser(user);
		if(isAdded==true)
		{
			
			out.println("<img src='image2.jpg' alt='image' />");
			
			/*out.println("Welcome <I>User<B>"+user.getUsername()+"</B></I>");*/
			out.println("<p>Congratulations !!! You have registered successfully</p>");
			out.println("<BR><A href=UserLogin.jsp>Login Now!</A>");
			out.println("</body>");
		}else{
			out.println("<body bgcolor='cyan'>");
			out.println("<center><h3>Welcome To Om Library Management System</h3></center>");
			out.println("<p>Error DUring Registration !!!</p>");
			out.println("<BR><A href=UserRegistration.jsp>Re-Register!</A>");
			out.println("</body>");
		}
	}
		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	public void destroy() {
		userDao.closeConnection();
		}

}
