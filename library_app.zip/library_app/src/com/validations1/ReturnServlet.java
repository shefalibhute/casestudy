package com.validations1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.IssueDao;
import com.dao.impl.IssueDaoImpl;
import com.models.Issue;


public class ReturnServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IssueDao issueDao;
	public void init(ServletConfig config) throws ServletException {
		System.out.println("+++++++ INIT() ++++++++++");
		issueDao = new IssueDaoImpl();
	}
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		int bookissueid=Integer.parseInt(request.getParameter("bookissueid"));
		String bookname=request.getParameter("bookname");
		String username=request.getParameter("username");
		/*int userid=Integer.parseInt(request.getParameter("userid"));*/
		int bookid=Integer.parseInt(request.getParameter("bookid"));
		String issuedate=request.getParameter("issuedate");
	    String returndate=request.getParameter("returndate");
	    String status=request.getParameter("status");
	    
	    Issue issue = new Issue();
	    
	    issue.setBookissueid(bookissueid);
	    issue.setBookname(bookname);
		issue.setUsername(username);
		issue.setBookid(bookid);
		issue.setIssuedate(issuedate);
		issue.setReturndate(returndate);
		issue.setStatus(status);
		
		System.out.println(issue.getBookid()); //test
		
		
		boolean isAdded= issueDao.returnBooks(issue);
		
		if(isAdded==true){
			out.println("<body background='6.jpg'>");
			out.println("<p>Congratulations !!! You have returned book Successfuly...</p>");
			out.println("<BR><A href=bookreturn.jsp>Back !</A>");
			out.println("</body>");
		}else{
			out.println("<body background='6.jpg'>");
			
			out.println("<p>Error during Updation!!!</p>");
			
			out.println("</body>");
		}	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		}
		public void destroy() {
			issueDao.closeConnection();
				}

	}
