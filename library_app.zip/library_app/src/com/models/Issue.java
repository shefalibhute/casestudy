package com.models;



public class Issue {
  private int bookissueid;
	private String bookname;
	private String username;
	private int bookid;
	private String issuedate;
	private String returndate;
	private String status;
	public int getBookissueid() {
		return bookissueid;
	}
	public void setBookissueid(int bookissueid) {
		this.bookissueid = bookissueid;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getIssuedate() {
		return issuedate;
	}
	public void setIssuedate(String issuedate) {
		this.issuedate = issuedate;
	}
	public String getReturndate() {
		return returndate;
	}
	public void setReturndate(String returndate) {
		this.returndate = returndate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Issue(int bookissueid, String bookname, String username,
			int bookid, String issuedate, String returndate, String status) {
		super();
		this.bookissueid = bookissueid;
		this.bookname = bookname;
		this.username = username;
		this.bookid = bookid;
		this.issuedate = issuedate;
		this.returndate = returndate;
		this.status = status;
	}
	public Issue() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}