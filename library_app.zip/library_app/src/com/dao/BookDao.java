package com.dao;

import com.models.Book;



public interface BookDao {
	boolean addBooks(Book book);
	boolean removeBooks(Book book);
	boolean updateBooks(Book book);
	void closeConnection();

}
