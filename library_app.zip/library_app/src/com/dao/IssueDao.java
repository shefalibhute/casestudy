package com.dao;


import com.models.Issue;

public interface IssueDao {
	boolean issueBooks(Issue issue);
	boolean returnBooks(Issue issue);
	void closeConnection();

}
