package com.dao;

import com.models.Userinfo;

public interface UserDao {
	boolean addUser(Userinfo user);
	boolean validateUser(Userinfo user);
	void closeConnection();
}
