package com.dao.impl;

import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.dao.BookDao;
import com.models.Book;


public class BookImpl implements BookDao {
Connection con;
	
	public  BookImpl(){
		try {
			
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("+++++++++ Driver Loaded ++++++++");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("+++++++++++ Connected to BD ++++++++++");
						
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public boolean addBooks(Book book) {
	
			boolean isAdded = false;
			try {
				String query = "insert into book values(?,?,?,?,?,?,?)";
				PreparedStatement ps = con.prepareStatement(query);
				ps.clearParameters();
				ps.setInt(1, book.getBookid());
				ps.setString(2, book.getCategory());
				ps.setString(3, book.getPublication());
				ps.setString(4,book.getBookname());
				ps.setString(5,book.getAuthor());
				ps.setInt(6, book.getCopies());
				ps.setInt(7, book.getPrice());
				
				
				int cnt = ps.executeUpdate();
				if(cnt==1)
				{
					isAdded = true;
					System.out.println("+++++++++++++ Book Added +++++++++++++");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		return isAdded;
	}

	public boolean removeBooks(Book book) {
		boolean isAdded = false;
		try {
		   	String query="delete from  book where bookid = ?";
		   	
		 
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
		
			
			ps.setInt(1, book.getBookid());
			
			
		
			int cnt=ps.executeUpdate();
			if (cnt == 1) {
				isAdded = true;
				System.out.println("+++++++++++++++ Book is deleted successfully  +++++++++++");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
			
		
		return isAdded;
	}
	public boolean updateBooks(Book book) {
		// TODO Auto-generated method stub
		boolean isAdded = false;
		try {
		   	
		   	String query="update book set category=?,publication=?,bookname=?,author=?,copies=?,price=? where bookid=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
			
			ps.setString(1, book.getCategory());
			ps.setString(2, book.getPublication());
			ps.setString(3,book.getBookname());
			ps.setString(4,book.getAuthor());
			ps.setInt(5, book.getCopies());
			ps.setInt(6, book.getPrice());
			ps.setInt(7, book.getBookid());
			
			
		
			
		
			int cnt=ps.executeUpdate();
			if (cnt == 1) {
				isAdded = true;
				System.out.println("+++++++++++++++ Book is updated successfully   +++++++++++");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
	

		return isAdded;
	}







	public void closeConnection() {
		try {
			con.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}
	}

	