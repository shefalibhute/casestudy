package com.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dao.AdminDao;
import com.models.User;

public class AdminDaoImpl implements AdminDao {
	
Connection con;
	
	public AdminDaoImpl(){
		try {
			
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("+++++++++ Driver Loaded ++++++++");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("+++++++++++ Connected to BD ++++++++++");
						
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	public boolean addUser(User user) {
		boolean isAdded = false;
		try {
			String query = "insert into admin values(?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.clearParameters();
			ps.setInt(1, 1);
			ps.setString(2, user.getFname());
			ps.setString(3, user.getLname());
			ps.setString(4,user.getUsername());
			ps.setString(5,user.getPassword());
			ps.setString(6, user.getContact());
			ps.setString(7, user.getEmail());
			
			
			int cnt = ps.executeUpdate();
			if(cnt==1)
			{
				isAdded = true;
				System.out.println("+++++++++++++ User Added +++++++++++++");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		return isAdded;
	}
	

	

	public boolean validateUser(User user) {
		boolean isValid = false;
		String query = "select * from admin where username = ? and password = ?";
		PreparedStatement ps1;
		try {
			ps1 = con.prepareStatement(query);
			ps1.clearParameters();
			ps1.setString(1,user.getUsername());
			ps1.setString(2,user.getPassword());
			ResultSet rs = ps1.executeQuery();
			System.out.println(user.getUsername()+" "+user.getPassword());
			if(rs.next())
			{
				isValid = true;
				System.out.println("+++++++++ User is Valid +++++++++");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isValid;
	}
	
	
	public void closeConnection() {
		try {
			if(con!=null)
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}


	

	


}
