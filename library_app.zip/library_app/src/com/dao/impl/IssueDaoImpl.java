package com.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.dao.IssueDao;
import com.models.Issue;

public class IssueDaoImpl implements IssueDao {
	Connection con;
	public  IssueDaoImpl(){
		try {
			
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("+++++++++ Driver Loaded ++++++++");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("+++++++++++ Connected to BD ++++++++++");
						
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public boolean issueBooks(Issue issue) {
		// TODO Auto-generated method stub

		boolean isAdded = false;
		try {
			String query = "insert into bookIssue1 values(?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.clearParameters();
			
			//ps.setInt(1, issue.getBookissueid());
			ps.setString(1,issue.getUsername());
			ps.setString(2,issue.getBookname());
			
			/*
			ps.setInt(4,issue.getBookid());
			ps.setString(5,issue.getIssuedate());
			ps.setString(6, issue.getReturndate());
			ps.setString(7, issue.getStatus());
			*/
			
			int cnt = ps.executeUpdate();
			if(cnt==1)
			{
				isAdded = true;
				System.out.println("+++++++++++++ Book Added +++++++++++++");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(isAdded);
		return isAdded;
	}
	public boolean returnBooks(Issue issue) {
		// TODO Auto-generated method stub
		boolean isAdded = false;
		try {
		   	
		   	String query="update book_issue set bookname=?,username=?,bookid=?,issuedate=?,returndate=?,status=? where bookissueid=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.clearParameters();
			
		
			ps.setString(1,issue.getBookname());
			ps.setString(2, issue.getUsername());
			ps.setInt(3, issue.getBookid());
			ps.setString(4,issue.getIssuedate());
			ps.setString(5, issue.getReturndate());
			ps.setString(6, issue.getStatus());
			ps.setInt(7, issue.getBookissueid());
			
			int cnt=ps.executeUpdate();
			if (cnt == 1) {
				isAdded = true;
				System.out.println("+++++++++++++++ Book is updated successfully   +++++++++++");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isAdded;
	}
	public void closeConnection() {
		// TODO Auto-generated method stub
		try {
			con.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}
		
	}
	


