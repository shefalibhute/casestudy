package com.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.Date;

import com.dao.UserDao;
import com.models.Userinfo;

public class UserDaoImpl implements UserDao {
	
Connection con;
	
	public UserDaoImpl(){
		try {
			
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("+++++++++ Driver Loaded ++++++++");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("+++++++++++ Connected to BD ++++++++++");
						
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	public boolean addUser(Userinfo user) {
		boolean isAdded = false;
		
		try {
			//String query = "insert into users values(user_seq.nextval,?,?,?,?,?,?,?)";
			String query = "insert into users values(?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);
			ps.clearParameters();
			ps.setString(1, user.getFname());
			ps.setString(2, user.getLname());
			ps.setString(3,user.getUsername());
			ps.setString(4,user.getPassword());
			ps.setString(5, user.getContact());
			ps.setString(6, user.getEmail());
			ps.setString(7,user.getMembtype());
			System.out.println(user.getFname());
			
			/*Date date = new Date(System.currentTimeMillis());
			if("Normal".equalsIgnoreCase(user.getMembtype())){
				date.setYear(date.getYear()+1);
			}else{
				date.setYear(date.getYear()+5);
			}
			ps.setDate(9,date);*/
			
			int cnt = ps.executeUpdate();
			if(cnt==1)
			{
				isAdded = true;
				System.out.println("+++++++++++++ User Added +++++++++++++");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	
		return isAdded;
	}
	public boolean validateUser(Userinfo user) {
		boolean isValid = false;
		String query = "select * from users where username = ? and password = ?";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(query);
			ps.clearParameters();
			System.out.println(user.getUsername()+" "+user.getPassword());
			ps.setString(1,user.getUsername());
			ps.setString(2,user.getPassword());
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				isValid = true;
				System.out.println("+++++++++ User is Valid +++++++++");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isValid;
	}
	
	public void closeConnection() {
		try {
			if(con!=null)
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}


	


}
