package com.dao;

import com.models.User;
//import com.models.Userinfo;

public interface AdminDao {
	boolean addUser(User user);
	boolean validateUser(User user);
	void closeConnection();
	
	
	

}
