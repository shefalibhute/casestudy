package cs.com.models;

public class Comms {

	private int bookId;
	private String bookName;
	private String comments;
	
	public Comms() {
		super();
	}

	public Comms(int bookId, String bookName, String comments) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.comments = comments;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
}
