package cs.com.models;

public class Books {
	private int bookId;
	private String bookName;
	private String author;
	private String availability;
	private String comments;
	
	public Books(){
		
	}
	public Books(int bookId, String bookName, String author,
			String availability, String comments) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.author = author;
		this.availability = availability;
		this.comments = comments;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}


	
	
}
