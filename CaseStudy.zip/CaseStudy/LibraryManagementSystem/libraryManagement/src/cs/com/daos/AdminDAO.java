package cs.com.daos;

import java.sql.Connection;

import cs.com.models.Administrator;

public interface AdminDAO {
	public Connection getConnection();
	public void closeConnection();
	public boolean validateAdmin(Administrator a);
	public boolean updateAdmin(Administrator a);
	public Administrator getAdmin(String userName);
	public boolean passwordUpdate(String userName,String newpassword);
}
