package cs.com.daos;
import cs.com.models.*;

import java.sql.Connection;
import java.util.ArrayList;

public interface CustomerDAO {
	 
	public Connection getConnection();
	public void closeConnection();
	public boolean addCustomer(Customer c);
	public Customer getCustomer(String username);
	public boolean updateCustomer(Customer c);
	public boolean updateCustomerDues();
	public boolean validateCustomer(Customer c);
	public boolean customerInactive(String userName);
	
	
	public ArrayList<Customer> getAllCustomers();
	public boolean removeCustomer(String username);
	public ArrayList<Customer> getNormalCustomers();
	public ArrayList<Customer> getPremiumCustomers();
	public ArrayList<Customer> getActiveCustomers();
	public ArrayList<Customer> getInactiveCustomers();
	
	
	public boolean passwordUpdate(String userName,String newpassword);
}
