package cs.com.test;

import java.sql.Date;

import cs.com.DaoImpl.AdminDaoImpl;
import cs.com.DaoImpl.IssueDaoImpl;
import cs.com.daos.AdminDAO;
import cs.com.daos.IssueDAO;
import cs.com.models.Administrator;


public class test {

	public static void main(String[] args){
		
		/*Date d=new Date(System.currentTimeMillis());
		String d1="2017-01-26";
		Date date=Date.valueOf(d1);
		System.out.println(d);
		System.out.println(date);
		long diff=d.getTime()-date.getTime();
		long diffdays=(diff)/(1000*60*60*24);
		System.out.println("Difference:"+diffdays);
		
		IssueDAO id=new IssueDaoImpl();
		id.removeIssueDet(4,"kausy7");
		AdminDAO ad=new AdminDaoImpl();
		Administrator admin=new Administrator();
		admin.setUserName("AdminSM");
		admin.setPassword("smmm123");
		System.out.println(ad.validateAdmin(admin));*/
	}
}
