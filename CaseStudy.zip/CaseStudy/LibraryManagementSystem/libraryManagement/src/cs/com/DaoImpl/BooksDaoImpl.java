package cs.com.DaoImpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import cs.com.daos.BooksDAO;
import cs.com.daos.IssueDAO;
import cs.com.models.Books;
import cs.com.models.Issue_Details;

public class BooksDaoImpl implements BooksDAO {

	private Connection con;
	private static final String conURL="jdbc:Oracle:thin:@localhost:1521:XE";
	private static final String dbUserName="system";
	private static final String dbPassword="system";
	private static String driverClass="oracle.jdbc.OracleDriver";
	IssueDAO idao=new IssueDaoImpl();

	public BooksDaoImpl() {
		try {
			Class.forName(driverClass);
			System.out.println("------DRIVER LOADED-----");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
	}

public Connection getConnection() {
		
		try {
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("-----CONNECTED TO DB-----");
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return con;
	}

	@Override
	public void closeConnection() {
		
		if(con!=null)
			try {
				con.close();
				System.out.println("---CONNECTION TO DB CLOSED----");
			} 
		catch (SQLException e) {
				e.printStackTrace();
			}

	}
	
	@Override
	public ArrayList<Books> getAllBooks() {
		
		String SQL="select * from books_tbl";
		
		ArrayList<Books>bookList=new ArrayList<Books>();
		Books b=null;
		getConnection();
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				b=new Books();
				b.setBookId(rs.getInt("bookid"));
				b.setBookName(rs.getString("bookname"));
				b.setAuthor(rs.getString("author"));
				b.setAvailability(rs.getString("availability"));
				
				bookList.add(b);	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return bookList;
	}

	@Override
	public ArrayList<Books> getAvailableBooks() {
		String SQL="select * from books_tbl where availability=?";
		ArrayList<Books>bookList=new ArrayList<Books>();
		Books b=null;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL,ResultSet.TYPE_SCROLL_SENSITIVE);
			ps.clearParameters();
			ps.setString(1, "Available");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				b=new Books();
				b.setBookId(rs.getInt("bookid"));
				b.setBookName(rs.getString("bookname"));
				b.setAuthor(rs.getString("author"));
				b.setAvailability(rs.getString("availability"));
				bookList.add(b);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return bookList;
	}

	@Override
	public ArrayList<Books> allIssuedBooks() {
		String SQL="select * from books_tbl where availability=?";
		ArrayList<Books>bookList=new ArrayList<Books>();
		Books b=null;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, "Issued");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				b=new Books();
				b.setBookId(rs.getInt("bookid"));
				b.setBookName(rs.getString("bookname"));
				b.setAuthor(rs.getString("author"));
				b.setAvailability(rs.getString("availability"));
				bookList.add(b);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return bookList;
	}

	@Override
	public ArrayList<Books> allReturnedBooks() {
		String SQL="select b.bookid,b.bookname,b.author,b.availability from issue_details c," +
				"books_tbl b where request=? and requeststatus=? and b.bookid=c.bookid";
		ArrayList<Books>bookList=new ArrayList<Books>();
		Books b=null;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, "Returned");
			ps.setString(2, "Approved");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				b=new Books();
				b.setBookId(rs.getInt("bookid"));
				b.setBookName(rs.getString("bookname"));
				b.setAuthor(rs.getString("author"));
				b.setAvailability(rs.getString("availability"));
				bookList.add(b);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return bookList;
	}

	@Override
	public boolean updateBook(Books b) {
boolean isUpdated=false;
		
		String sql="update books_tbl set bookname=?,"
				+"author=?,availability=?"
				+"where bookid=?";
		getConnection();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ps.clearParameters();
			ps.setString(1, b.getBookName());
			ps.setString(2, b.getAuthor());
			ps.setString(3, b.getAvailability());
			ps.setInt(4, b.getBookId());
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("---BOOK UPDATED SUCCESSFULLY----");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		
		return isUpdated;
	}

	@Override
	public boolean issueBook(int bookId, Issue_Details id) {
		boolean isIssued=false;
		String sql="update books_tbl set availability=? "
					+"where bookid=?";
		String SQL="update issue_details set issuedate=?,requeststatus=?," +
				"fineamount=?,remarks=? where bookid=?";
		getConnection();
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			PreparedStatement ps1=con.prepareStatement(SQL);
			ps.clearParameters();
			ps1.clearParameters();
			ps.setString(1,"Issued");
			ps.setInt(2, bookId);
			
			ps1.setDate(1,id.getIssueDate());
			ps1.setString(2,"Approved");
			ps1.setInt(3,id.getFineAmount());
			ps1.setString(4, id.getRemarks());
			ps1.setInt(5, bookId);
			
			int cnt=ps.executeUpdate();
			ps1.executeUpdate();
			if(cnt==1){
				isIssued=true;
				System.out.println("----BOOK ISSUED SUCCESSFULLY----");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return isIssued;
	}

	@Override
	public boolean returnBook(int bookId,Issue_Details id) {
		boolean isReturned=false;
		String sql="update books_tbl set availability=?"
					+"where bookid=?";
		String SQL="update issue_details set requeststatus=?,remarks=?," +
				"fineamount=?,returndate=? where bookid=?";
		getConnection();
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			PreparedStatement ps1=con.prepareStatement(SQL);
			ps.clearParameters();
			ps1.clearParameters();
			
			ps.setString(1,"Available");
			ps.setInt(2, bookId);
			
			ps1.setString(1,"Approved");
			ps1.setString(2, id.getRemarks());
			ps1.setLong(3, idao.calcFineAmount1(id.getIssueDate(),
					new Date(System.currentTimeMillis())));
			ps1.setDate(4, new Date(System.currentTimeMillis()));
			ps1.setInt(5, bookId);
			ps1.executeUpdate();
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isReturned=true;
				System.out.println("----BOOK RETURNED SUCCESSFULLY----");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return isReturned;
	}

	@Override
	public boolean addBook(Books b) {
		String SQL="insert into books_tbl(bookid,bookname,author,availability)" +
				" values(?,?,?,?)";
		String sql="select max(bookid) from books_tbl";
		getConnection();
		boolean isAdded=false;
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			PreparedStatement ps1=con.prepareStatement(sql);
			ResultSet rs=ps1.executeQuery();
			rs.next();
			int bookId=rs.getInt(1)+1;
				ps.clearParameters();
				ps.setInt(1, bookId);
				ps.setString(2, b.getBookName());
				ps.setString(3, b.getAuthor());
				ps.setString(4, "Available");
				int count=ps.executeUpdate();
				if(count==1)
				{
					isAdded=true;
					System.out.println("----BOOK ADDED SUCCESSFULLY----");
				}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
			
		return isAdded;
	}

	@Override
	public boolean removeBook(int bookId) {
String SQL="delete from books_tbl where bookid=?";
		
		boolean isDeleted=false;
		getConnection();
		
		try {
		
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setInt(1, bookId);
			
			int cnt=ps.executeUpdate();
			
			if(cnt==1)
			{
				isDeleted=true;
				System.out.println("----BOOK DELETED SUCCESSFULLY");
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return isDeleted;

	}

	@Override
	public Books getBook(int bookId) {
		
		String SQL="select * from books_tbl where bookid=?";
		Books b=null;
		
		getConnection();
		
		try {
			
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setInt(1, bookId);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){ 
				b=new Books();
				b.setBookId(rs.getInt("bookid"));
				b.setBookName(rs.getString("bookname"));
				b.setAuthor(rs.getString("author"));
				b.setAvailability(rs.getString("availability"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return b;
	}

	@Override
	public Books getBook(String bookName, String author) {
		String SQL="select * from books_tbl where bookname=? and author=?";
		Books b=null;
		
		getConnection();
		
		try {
			
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, bookName);
			ps.setString(2, author);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){ 
				b=new Books();
				b.setBookId(rs.getInt("bookid"));
				b.setBookName(rs.getString("bookname"));
				b.setAuthor(rs.getString("author"));
				b.setAvailability(rs.getString("availability"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return b;
	}

}
