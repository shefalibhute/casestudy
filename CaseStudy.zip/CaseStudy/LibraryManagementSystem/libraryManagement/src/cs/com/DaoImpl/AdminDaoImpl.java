package cs.com.DaoImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cs.com.daos.AdminDAO;
import cs.com.models.Administrator;

public class AdminDaoImpl implements AdminDAO {

	private Connection con;
	private static final String conURL="jdbc:Oracle:thin:@localhost:1521:XE";
	private static final String dbUserName="system";
	private static final String dbPassword="system";
	private static String driverClass="oracle.jdbc.OracleDriver";
	
	public AdminDaoImpl() {
		try {
			Class.forName(driverClass);
			System.out.println("------DRIVER LOADED-----");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
	}
	
	@Override
	public Connection getConnection() {
		
		try {
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("-----CONNECTED TO DB-----");
		} 
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return con;
	}

	@Override
	public void closeConnection() {
		
		if(con!=null)
			try {
				con.close();
				System.out.println("---CONNECTION TO DB CLOSED----");
			} 
		catch (SQLException e) {
				e.printStackTrace();
			}

	}

	@Override
	public boolean validateAdmin(Administrator a) {
		
		String SQL="select * from admin_tbl where username=? and password=?";
		boolean isValid=false;
		getConnection();
		
		try{
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, a.getUserName());
			ps.setString(2, a.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				isValid=true;
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return isValid;
	}

	@Override
	public boolean updateAdmin(Administrator c) {
		String SQL="update admin_tbl set firstname=?,"
				+ "lastname=?,password=?,emailid=?,"
				+ "phoneno=? where username=?";
		
		getConnection();
		boolean isUpdated=false;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, c.getFirstName());
			ps.setString(2, c.getLastName());
			ps.setString(3, c.getPassword());
			ps.setString(4, c.getEmailId());
			ps.setString(5, c.getPhoneNo());
			ps.setString(6, c.getUserName());
			int cnt=ps.executeUpdate();
			if(cnt==1)
			{
				isUpdated=true;
				System.out.println("---CUSTOMER UPDATED SUCCESSFULLY----");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		
		return isUpdated;
	}

	@Override
	public Administrator getAdmin(String userName) {
		
		String SQL="select * from admin_tbl where username=?";
		Administrator c=null;
		getConnection();
		
		try {
			c=new Administrator();
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, userName);
			c.setUserName(userName);
			ResultSet rs= ps.executeQuery();
			if(rs.next()){
			c.setPassword(rs.getString("password"));
			c.setFirstName(rs.getString("firstname"));
			c.setLastName(rs.getString("lastname"));
			c.setEmailId(rs.getString("emailid"));
			c.setPhoneNo(rs.getString("phoneno"));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally{
			closeConnection();
		}
		return c;
	}

	@Override
	public boolean passwordUpdate(String userName,String newpassword) {
		
		String SQL="update admin_tbl set password=? " +
				"where userName=?";
		getConnection();
		boolean isUpdated=false;
		
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, newpassword);
			ps.setString(2, userName);
			
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isUpdated=true;
				System.out.println("---PASSWORD UPDATED");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isUpdated;
	}

}
