package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.com.DaoImpl.CommsDaoImpl;
import cs.com.daos.CommsDAO;
import cs.com.models.Comms;

public class SubmitReviewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CommsDAO cd=new CommsDaoImpl();
	Comms c=null;

	public void init(ServletConfig config) throws ServletException {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		RequestDispatcher rd=request.getRequestDispatcher("/homepage1.jsp");
		
		int bookId=Integer.parseInt(request.getParameter("bookId"));
		String bookName=request.getParameter("bookName");
		String comments=request.getParameter("comments");
		c=new Comms();
		c.setBookId(bookId);
		c.setBookName(bookName);
		c.setComments(comments);
		boolean isAdded=cd.addComments(c);
		if(isAdded){
			out.println("<h3>Comment has been submitted successfully</h3>");
			rd.include(request, response);
		}
		else{
			out.println("<h3>Error in submitting the comment. Please try after some time</h3>");
			rd.include(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
