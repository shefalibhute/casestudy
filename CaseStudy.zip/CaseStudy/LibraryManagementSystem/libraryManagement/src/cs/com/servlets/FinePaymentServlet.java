package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cs.com.DaoImpl.IssueDaoImpl;
import cs.com.daos.IssueDAO;

public class FinePaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IssueDAO id=new IssueDaoImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String userName=(String)session.getAttribute("userName");
		int bookId=Integer.parseInt((String)session.getAttribute("bookId"));
		String bookName=(String)session.getAttribute("bookName");
		
		boolean b=id.updateFineDetails(userName, bookId, bookName);
		
		if(b){
		RequestDispatcher rd=request.getRequestDispatcher("/success.jsp");
		rd.forward(request, response);
		}
		else
		{
			out.println("<h3><b><i>Error during payment process. Please try again</i></b></h3>");
			RequestDispatcher rd=request.getRequestDispatcher("/homepage1.jsp");
			rd.include(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
