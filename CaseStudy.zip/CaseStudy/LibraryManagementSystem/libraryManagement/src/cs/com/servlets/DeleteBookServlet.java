package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.com.DaoImpl.BooksDaoImpl;
import cs.com.DaoImpl.CommsDaoImpl;
import cs.com.daos.BooksDAO;
import cs.com.daos.CommsDAO;

public class DeleteBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BooksDAO cd=new BooksDaoImpl();
	CommsDAO cd1=new CommsDaoImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		int bookId=Integer.parseInt(request.getParameter("bookId"));
		
		boolean isDeleted=cd.removeBook(bookId);
		cd1.removeComment(bookId);
		if(isDeleted){
			out.println("<h3>Book has been deleted successfully</h3>");
			RequestDispatcher rd=request.getRequestDispatcher("/homepage.jsp");
			rd.include(request, response);
		}
		else{
			out.println("<h3>Error in deleting the book <br>Please try again later</h3>");
			RequestDispatcher rd=request.getRequestDispatcher("/homepage.jsp");
			rd.include(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
