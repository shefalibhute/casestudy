package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.com.DaoImpl.IssueDaoImpl;
import cs.com.daos.IssueDAO;
import cs.com.models.Issue_Details;

public class ReturnRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IssueDAO idao=new IssueDaoImpl();
	
	public void init(ServletConfig config) throws ServletException {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		RequestDispatcher rd=request.getRequestDispatcher("/homepage1.jsp");
		Issue_Details id;
		
		int bookId=Integer.parseInt(request.getParameter("bookId"));
		id=idao.getIssueDetails(bookId,"Approved");
		
		id.setRequest("Return");
		id.setRequestStatus("Pending");
		boolean isAdded=idao.updateIssueDetails(id);
		if(isAdded){
			out.println("<h3>Book Return has been requested successfully</h3>");
			rd.include(request, response);
		}
		else
		{
			out.println("<h3>Sorry there is an error. Please try again</h3>");
			rd.include(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
