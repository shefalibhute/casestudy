package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cs.com.DaoImpl.AdminDaoImpl;
import cs.com.DaoImpl.CustomerDaoImpl;
import cs.com.daos.AdminDAO;
import cs.com.daos.CustomerDAO;
import cs.com.models.Administrator;
import cs.com.models.Customer;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CustomerDAO cd=new CustomerDaoImpl();
	AdminDAO ad=new AdminDaoImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		
		HttpSession session = request.getSession();
		session.setAttribute("userName", userName);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		Customer cust=new Customer();
		cust.setUserName(userName);
		cust.setPassword(password);
		
		Administrator a=new Administrator();
		a.setUserName(userName);
		a.setPassword(password);
		
		boolean admin=ad.validateAdmin(a);
		boolean valid=cd.validateCustomer(cust);
	
		if(admin){
			a=ad.getAdmin(userName);
			session.setAttribute("Admin", a);
			
			RequestDispatcher rd=request.getRequestDispatcher("/homepage.jsp");
			rd.include(request, response);
		}
		else if(valid){
		
			cust=cd.getCustomer(userName);
			session.setAttribute("customer", cust);
			
			if(cd.customerInactive(userName)){
				
				out.println("<h3><b><i>You must return the book and" +
						" pay the fine to access any services!</i></b></h3>");
			
				RequestDispatcher rd=request.getRequestDispatcher("/returnandpay.jsp");
				rd.include(request, response);
			
			}
			else{
			
				RequestDispatcher rd=request.getRequestDispatcher("/homepage1.jsp");
				rd.include(request, response);
			}
		}
		else
		{	
			out.println("<body><h3>You have entered the wrong credentials</h3>" +
					"<h4>Please re-enter the correct details</h4></body>");
			
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			rd.include(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
