package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.com.DaoImpl.CommsDaoImpl;
import cs.com.daos.CommsDAO;

public class DeleteReviewsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CommsDAO cd=new CommsDaoImpl();
	
	public void init(ServletConfig config) throws ServletException {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		RequestDispatcher rd=request.getRequestDispatcher("/homepage.jsp");
		
		int bookId=Integer.parseInt(request.getParameter("bookId"));
		boolean isRemoved=cd.removeComment(bookId);
		if(isRemoved){
			out.println("<h3><i><b>Reviews have been deleted</b></i></h3>");
			rd.include(request, response);
		}
		else{
			out.println("<h3><i><b>Error in deleting the comment. Try again in some time</b></i></h3>");
			rd.include(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
