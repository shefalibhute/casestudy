package cs.com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cs.com.DaoImpl.BooksDaoImpl;
import cs.com.DaoImpl.IssueDaoImpl;
import cs.com.daos.BooksDAO;
import cs.com.daos.IssueDAO;
import cs.com.models.Books;
import cs.com.models.Issue_Details;

public class IssueRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IssueDAO idao=new IssueDaoImpl();
	BooksDAO bd=new BooksDaoImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		RequestDispatcher rd=request.getRequestDispatcher("/homepage1.jsp");
		
		HttpSession session=request.getSession();
		String userName=(String) session.getAttribute("userName");
		int bookId=Integer.parseInt(request.getParameter("bookId"));
		Books b= bd.getBook(bookId);
		
		int count=idao.countBooksIssued(userName);
		
		if(count<2){
			
			Issue_Details id=new Issue_Details();
			id.setUserName(userName);
			id.setBookId(bookId);
			id.setBookName(b.getBookName());
			id.setRequest("Issue");
			id.setRequestStatus("Pending");
		
			boolean isAdded=idao.addIssueDetails(id);
			if(isAdded){
				out.println("<h3>Book Issue has been requested successfully</h3>");
				rd.include(request, response);
			}
			else
			{
				out.println("<h3>Sorry there is an error. Please try again</h3>");
				rd.include(request, response);
			}
		}
		else
		{
			out.println("<h3>Sorry you can only issue two books at a time. Please return a book.</h3>");
			rd.include(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
