package cs.com.filters;

import java.io.IOException;
import java.io.PrintWriter;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EmailFilter implements Filter {


    public EmailFilter() {
        // TODO Auto-generated constructor stub
    }

	public void destroy() {
		// TODO Auto-generated method stub
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req=(HttpServletRequest)request;
		HttpServletResponse res=(HttpServletResponse)response;
		
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		RequestDispatcher rd=req.getRequestDispatcher("/register.html");
		String emailId=request.getParameter("emailId");
		
		if(!validateEmail(emailId)){
			out.println("<h4>Please enter a valid Email ID<h4>");
			rd.include(request, response);
		}
		else 
		chain.doFilter(request, response);
	}

	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

	public boolean validateEmail(String emailId){
		boolean result=true;
		try {
			InternetAddress emailaddr=new InternetAddress(emailId);
			emailaddr.validate();
		} catch (AddressException e) {
			result=false;
		}
		return result;
	}
}
